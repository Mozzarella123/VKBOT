﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Collections.Specialized;
using VkNet;
using VkNet.Enums.Filters;
using VkNet.Exception;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace MemLoaderClient
{
    

    public partial class Form1 : Form
    {
        
        public Form1(ref VkApi Api,bool ConfigAlreadyExist,Form parent)
        {
            
            
            InitializeComponent();
            _ConfigAlreadyExist = ConfigAlreadyExist;

           
            if (Api != null && Api.Token != null)
                richTextBox1.Text += "LogIn success\n" + Api.Token + "\n";
            else
                richTextBox1.Text += "invalid Login\n";
            _Parent = parent;
            WebClient wc = new WebClient();
            wc.DownloadFile("http://brusgrad.ru/php/json_parse.txt", "FileLinks.txt");
            FileLinks = File.ReadAllText("FileLinks.txt");
            obj = JsonConvert.DeserializeObject<RootObject[]>(FileLinks);
            _Api = Api;
            TargetGroupId = 142367703;
            if (!Directory.Exists("bg"))
                Directory.CreateDirectory("bg");
            try
            {
                //SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                //builder.UserID = "cw44342_botvk";
                //builder.DataSource = "vh26.timeweb.ru";
                //builder.Password = "12345qwe";
                //builder.InitialCatalog = "cw44342_botvk";
                //builder.TrustServerCertificate = true;
               
                //builder.PersistSecurityInfo = true;
                //builder.IntegratedSecurity = false;
                //richTextBox1.Text += builder.ConnectionString;
                //db = new SqlConnection(builder.ConnectionString);

                string serverName = "vh26.timeweb.ru"; // Адрес сервера (для локальной базы пишите "localhost")
                string userName = "cw44342_botvk"; // Имя пользователя
                string dbName = "cw44342_botvk"; //Имя базы данных
                string port = "3306"; // Порт для подключения
                string password = "12345qwe"; // Пароль для подключения
                string connStr = "server=" + serverName +
                    ";user=" + userName +
                    ";database=" + dbName +
                    ";port=" + port +
                    ";password=" + password + ";";
                db = new MySqlConnection(connStr);
                db.Open();

                
            }
            catch(Exception e)
            {
                richTextBox1.Text += e.Message;
            }
            //obj[0].LoadAndAddToBase(_Api,db);
        }

        MySqlConnection db;

        Form _Parent;

        bool _ConfigAlreadyExist;

        string FileLinks;

        RootObject[] obj;

        long TargetGroupId;


        VkApi _Api;

        private void button1_Click(object sender, EventArgs e)
        {
            foreach(RootObject o in obj)
            richTextBox1.Text += o.LoadAndAddToBase(_Api, db)+"\n";
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            db.Close();
            File.Delete("FileLinks.txt");
            _Parent.Close();
            //File.Encrypt("Config.txt");
        }

       

        private void ChooseLinkFileDialog_FileOk(object sender, CancelEventArgs e)
        {
            
            
        }
    }
    public class RootObject
    {
        public string title { get; set; }
        public string description { get; set; }
        public string image_url { get; set; }
        public string PhotoID { get; set; }
        public bool AllCorrect { get; set; }
        public string LoadAndAddToBase(VkApi Api,MySqlConnection db)
        {
            AllCorrect = true;
            WebClient wc = new WebClient();
            string file = "bg\\" + title + ".jpg";
            
            for (int i = 0; File.Exists(file); i++)
            {
                file = "bg\\" + title + i + ".jpg";
            }
            string ret = "";
            try
            {
                wc.DownloadFile(image_url, file);
                var uploadServer = Api.Photo.GetUploadServer(243751267, 142367703);
                //Загрузить файл.

                var responseFile = Encoding.ASCII.GetString(wc.UploadFile(uploadServer.UploadUrl, file));

                //Сохранить загруженный файл
                var photos = Api.Photo.Save(new VkNet.Model.RequestParams.PhotoSaveParams
                {
                    SaveFileResponse = responseFile,
                    AlbumId = 243751267,
                    GroupId = 142367703,
                    Caption = title
                });
                PhotoID = photos[0].ToString();
                
            }
            catch(Exception e)
            {
                AllCorrect = false;
                return e.Message;
            }

            try
            {
                MySqlScript addCommand = new MySqlScript(db,"INSERT INTO attachments(photoid_vk)VALUES('"+PhotoID+"');SET @ATLastID:= LAST_INSERT_ID();INSERT INTO articles(title, description)VALUES('"+title+"', '"+description+"');SET @ARTLastID:= LAST_INSERT_ID();INSERT INTO attach_relations(attachment_id, article_id)VALUES(@ATLastID, @ARTLastID);");
                if (AllCorrect) addCommand.Execute();
                return "файл " + file + " загружен и добавлен в базу";
            }
            catch(Exception e)
            {
                ret += e.Message+";";
                
            }

            return ret;

        }
    }
}
