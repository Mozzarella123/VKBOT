﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VkNet;
using VkNet.Enums.Filters;
using VkNet.Exception;
using System.IO;

namespace MemLoaderClient
{
    
    public partial class LogInForm : Form
    {
        string[] getLogPass(string[] strAr)
        {
            string[] ret = new string[2];
            foreach (string str in strAr)
            {
                if (str.Contains("Login:"))
                {
                    for (int i = str.IndexOf(":") + 1; i < str.Length; i++)
                        ret[0] += str[i];
                }
                if (str.Contains("Pass:"))
                {
                    for (int i = str.IndexOf(":") + 1; i < str.Length; i++)
                        ret[1] += str[i];
                }
            }
            return ret;
        }
        bool _ConfigAlreadyExist;
        public LogInForm(VkApi _Api, Form NextForm)
        {
            InitializeComponent();
            
            if (!File.Exists("Config.txt"))
            {
                File.Create("Config.txt");
                _ConfigAlreadyExist = false;
            }
            else
            {
                _ConfigAlreadyExist = true;
                //File.Decrypt("Config.txt");
                string[] LogPass = getLogPass(File.ReadAllLines("Config.txt"));
                LoginTB.Text = LogPass[0];
                PassTB.Text = LogPass[1];

            }
            
            Api = _Api;
            ConfigAlreadyExist = _ConfigAlreadyExist;
            _NextForm = NextForm;
        }

        VkApi Api;
        bool ConfigAlreadyExist;
        Form _NextForm;

        private void button1_Click(object sender, EventArgs e)
        {
            
            ErrorLabel.Text = "";

            try
            {

                Api.Authorize(new ApiAuthParams
                {
                    ApplicationId = 5925267,
                    Login = LoginTB.Text,
                    Password = PassTB.Text,
                    Settings = Settings.All,

                });
                if (!_ConfigAlreadyExist||checkBox1.Checked)
                {
                    string[] Configs;
                    if (checkBox1.Checked == false)
                        Configs = new string[1] { "Login:" + LoginTB.Text };
                    else
                    Configs=new string[2]{ "Login:" + LoginTB.Text, "Pass:" + PassTB.Text };
                    File.WriteAllLines("Config.txt", Configs);
                }

                this.Visible=false;
                _NextForm =new Form1(ref Api,ConfigAlreadyExist,this);
                _NextForm.Show();
            }
            catch (VkApiAuthorizationException)
            {

                ErrorLabel.Text = "incorrect Login or Password";
                return;
            }
        }

        private void LogInForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }
    }
}
