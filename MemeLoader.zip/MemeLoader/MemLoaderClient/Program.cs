﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MemLoaderClient
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Form NextForm=null;
            VkNet.VkApi Api = new VkNet.VkApi();
            Application.Run(new LogInForm(Api,NextForm));
            //NextForm.Show();
        }
    }
}
