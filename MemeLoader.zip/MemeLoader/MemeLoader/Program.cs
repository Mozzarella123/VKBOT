﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Data.SqlClient;

namespace MemeLoader
{
    class Program
    {
        abstract class Command
        {
            protected HttpWebRequest req;
            protected HttpWebResponse resp;
            protected StreamReader reader;
            public virtual void Execute(object[] items)
            {

            }
        }
        class GetUploadServer:Command
        {
            public class Response
            {
                public string upload_url { get; set; }
                public int album_id { get; set; }
                public int user_id { get; set; }
            }

            public class RootObject
            {
                public Response response { get; set; }
            }

            public override void Execute(object[] items)
            {
                base.Execute(items);
                req = (HttpWebRequest)WebRequest.Create("https://api.vk.com/method/photos.getMessagesUploadServer&access_token=0af2d08e1ae155f15fa5029db5c9aec1b8470a5aeecf803ad184ab8f1bd07159d047c212cd19b609cdb16");
                resp = (HttpWebResponse)req.GetResponse();
                reader = new StreamReader(resp.GetResponseStream());
                Console.WriteLine(reader.ReadToEnd());
            }

        }
        

        static void Main(string[] args)
        {
            string connStr = "Data Source=176.57.210.32\\SQLEXPRESS;Network Library = DBMSSOCN; Initial Catalog = test; User ID = testus; Password = qw12";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                Console.WriteLine("Соедение успешно произведено");
            }
            catch (SqlException se)
            {
                Console.WriteLine("Ошибка подключения:{0}", se.Message);
                
            }

            
            Console.ReadLine();
        }
    }
}
